import SwiftUI

/// Full-width pill CTA. Dark variant = primary submit, Light variant = secondary. §2.5.
struct PrimaryButton: View {
    enum Style { case dark, light }

    let title: String
    var style: Style = .dark
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.bodyLG)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 18)
                .foregroundColor(style == .dark ? .white : .textOnLight)
                .background(
                    Group {
                        if style == .dark {
                            LinearGradient(colors: [.black, .heraeInk], startPoint: .top, endPoint: .bottom)
                        } else {
                            Color.surfaceCardPure
                        }
                    }
                )
                .clipShape(Capsule())
                .cardShadow()
        }
    }
}
