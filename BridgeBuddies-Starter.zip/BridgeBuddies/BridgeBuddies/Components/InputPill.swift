import SwiftUI

/// White rounded-pill field: label left, divider, value right.
/// Used across Login, Profile Setup, Edit Profile. §2.1 in UI_SPEC.
struct InputPill: View {
    let label: String
    @Binding var text: String
    var isSecure: Bool = false
    var isMultiline: Bool = false
    var helperText: String? = nil

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(alignment: isMultiline ? .top : .center, spacing: 12) {
                Text(label)
                    .font(.bodyMD)
                    .foregroundColor(.textOnLightMuted)
                    .fixedSize(horizontal: true, vertical: false)

                Rectangle()
                    .fill(Color.textOnLightMuted.opacity(0.3))
                    .frame(width: 1, height: isMultiline ? 60 : 20)

                Group {
                    if isMultiline {
                        TextField("", text: $text, axis: .vertical)
                            .lineLimit(3...6)
                    } else if isSecure {
                        SecureField("", text: $text)
                    } else {
                        TextField("", text: $text)
                    }
                }
                .font(.bodyLG)
                .foregroundColor(.textOnLight)
            }
            .padding(.horizontal, 20)
            .padding(.vertical, isMultiline ? 16 : 14)
            .background(Color.surfaceCardPure)
            .clipShape(RoundedRectangle(cornerRadius: isMultiline ? Radius.card : Radius.pill))
            .cardShadow()

            if let helperText {
                Text(helperText)
                    .font(.bodySM)
                    .foregroundColor(.textOnDarkMuted)
                    .padding(.horizontal, 8)
            }
        }
    }
}
