import SwiftUI

enum AppTab: CaseIterable {
    case home, chat, explore, profile

    var icon: String {
        switch self {
        case .home: return "house"
        case .chat: return "bubble.left"
        case .explore: return "safari"
        case .profile: return "hexagon"
        }
    }
}

/// Floating pill nav bar with active tab elevated as a black circle. §2.7.
struct BottomTabBar: View {
    @Binding var selected: AppTab

    var body: some View {
        HStack {
            ForEach(AppTab.allCases, id: \.self) { tab in
                Spacer()
                Button(action: { selected = tab }) {
                    ZStack {
                        if selected == tab {
                            Circle()
                                .fill(Color.black)
                                .frame(width: 52, height: 52)
                                .offset(y: -10)
                                .shadow(color: .black.opacity(0.3), radius: 8, y: 4)
                        }
                        Image(systemName: tab.icon)
                            .foregroundColor(selected == tab ? .white : .textOnLightMuted)
                            .offset(y: selected == tab ? -10 : 0)
                    }
                }
                Spacer()
            }
        }
        .padding(.vertical, 14)
        .background(Color.surfaceCardPure)
        .clipShape(Capsule())
        .cardShadow()
        .padding(.horizontal, Spacing.screenH)
    }
}
