import SwiftUI

/// Large white rounded card housing a scrollable list. §2.6.
struct ListCard<Content: View>: View {
    @ViewBuilder let content: Content

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                content
            }
            .padding(20)
        }
        .background(Color.surfaceCardPure)
        .clipShape(RoundedRectangle(cornerRadius: Radius.card))
        .cardShadow()
    }
}
