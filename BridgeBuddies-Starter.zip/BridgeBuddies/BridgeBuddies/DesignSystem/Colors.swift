import SwiftUI

// MARK: - Bridge Buddies Color Tokens
// Source of truth: UI_SPEC.md §1. Do not hardcode hex values in screens/components — use these.

extension Color {
    // Brand gradient (maroon) — core social/content screens
    static let bgBrandTop = Color(hex: "6F1739")
    static let bgBrandBottom = Color(hex: "0D0D0D")

    // Neutral gradient (gray) — utility/auth/chrome screens
    static let bgNeutralTop = Color(hex: "D8D8D8")
    static let bgNeutralBottom = Color(hex: "0D0D0D")

    // Surfaces
    static let surfaceCard = Color(hex: "FBF9F6")       // warm off-white — data-dense screens
    static let surfaceCardPure = Color(hex: "FFFFFF")   // pure white — onboarding/forms
    static let surfaceCardAlt = Color(hex: "F2EFEA")

    // Text
    static let textOnDark = Color.white
    static let textOnDarkMuted = Color(hex: "C9C9C9")
    static let textOnLight = Color(hex: "2B2B2B")
    static let textOnLightMuted = Color(hex: "8A8A8A")

    // Status
    static let statusAvailable = Color(hex: "6FCF3D")
    static let statusBusy = Color(hex: "E5484D")
    static let statusAway = Color(hex: "F2A93B")
    static let statusNone = Color(hex: "B8B8B8")

    // School accent (CMU — v1 only, swappable per §1)
    static let schoolPrimary = Color(hex: "6F1739")
    static let schoolSecondary = Color(hex: "C9A24B")

    // Herae reference palette — used sparingly for dashboard module accents (§1)
    static let heraeSage = Color(hex: "D6DDC6")
    static let heraeCream = Color(hex: "F4E0AC")
    static let heraeOlive = Color(hex: "8E9E6E")
    static let heraeInk = Color(hex: "10120C")

    init(hex: String) {
        let scanner = Scanner(string: hex)
        var rgbValue: UInt64 = 0
        scanner.scanHexInt64(&rgbValue)
        let r = Double((rgbValue & 0xFF0000) >> 16) / 255.0
        let g = Double((rgbValue & 0x00FF00) >> 8) / 255.0
        let b = Double(rgbValue & 0x0000FF) / 255.0
        self.init(red: r, green: g, blue: b)
    }
}

extension LinearGradient {
    static let brandBackground = LinearGradient(
        colors: [.bgBrandTop, .bgBrandBottom],
        startPoint: .topLeading, endPoint: .bottomTrailing
    )
    static let neutralBackground = LinearGradient(
        colors: [.bgNeutralTop, .bgNeutralBottom],
        startPoint: .topLeading, endPoint: .bottomTrailing
    )
}
