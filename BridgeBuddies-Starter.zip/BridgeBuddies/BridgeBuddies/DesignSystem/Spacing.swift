import SwiftUI

enum Spacing {
    static let screenH: CGFloat = 24
    static let stack: CGFloat = 16
    static let section: CGFloat = 32
}

enum Radius {
    static let pill: CGFloat = 999
    static let card: CGFloat = 28
}

extension View {
    /// Standard floating card shadow (UI_SPEC §1 elevation token).
    func cardShadow() -> some View {
        self.shadow(color: .black.opacity(0.15), radius: 12, x: 0, y: 8)
    }
}
