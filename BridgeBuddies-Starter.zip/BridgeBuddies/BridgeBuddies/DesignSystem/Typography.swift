import SwiftUI

// MARK: - Bridge Buddies Typography
// Display = serif (Playfair Display), Body = system sans.
// Scale follows Herae's 12/16/20/24/28/32/40 step (UI_SPEC §1).
// Add "PlayfairDisplay-Bold" / "PlayfairDisplay-Regular" to the target and Info.plist fonts list
// before these .custom() calls will resolve — falls back to system serif otherwise.

extension Font {
    static func displayFont(size: CGFloat, weight: Font.Weight = .bold) -> Font {
        .custom("PlayfairDisplay-Bold", size: size)
    }

    static let displayLG = displayFont(size: 40)   // splash logo
    static let displayMD = displayFont(size: 32)   // screen titles
    static let displaySM = displayFont(size: 28)   // greetings

    static let bodyLG = Font.system(size: 20, weight: .semibold)   // field values, list primary
    static let bodyMD = Font.system(size: 16, weight: .regular)    // field labels, secondary
    static let bodySM = Font.system(size: 12, weight: .regular)    // helper text, timestamps
    static let caption = Font.system(size: 12, weight: .medium)    // eyebrow, uppercase tracked
}
