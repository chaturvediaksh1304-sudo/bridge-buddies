import SwiftUI

struct HomeView: View {
    @State private var pulseFilter = "All"
    let userName = "Zainab"

    var body: some View {
        ZStack(alignment: .top) {
            LinearGradient.neutralBackground.ignoresSafeArea()

            VStack(spacing: 0) {
                // Header — brand gradient block
                ZStack(alignment: .topLeading) {
                    LinearGradient.brandBackground
                        .clipShape(RoundedCorner(radius: 40, corners: [.bottomLeft, .bottomRight]))
                        .frame(height: 220)

                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Hi \(userName)!")
                                .font(.displaySM)
                                .foregroundColor(.textOnDark)
                            Text("Your next connection is waiting.")
                                .font(.bodyMD)
                                .foregroundColor(.textOnDarkMuted)
                        }
                        Spacer()
                        DualOrbAvatar(size: 56)
                    }
                    .padding(.horizontal, Spacing.screenH)
                    .padding(.top, 60)
                }

                ScrollView {
                    VStack(spacing: 20) {
                        // Progress ring — activity summary
                        ProgressRing(
                            segments: [
                                .init(label: "Friends", value: 18, color: .heraeSage),
                                .init(label: "Mentors", value: 2, color: .heraeCream),
                                .init(label: "Mentees", value: 7, color: .schoolSecondary)
                            ],
                            centerValue: "27",
                            centerLabel: "Connections"
                        )

                        // Stat trio
                        StatTrioRow(stats: [
                            .init(label: "New Matches", value: "03"),
                            .init(label: "Pending", value: "01"),
                            .init(label: "Active Chats", value: "05")
                        ])
                        .padding(.horizontal, Spacing.screenH)

                        // Today's buddy
                        DetailCardWithIconCTA(
                            icon: "person.crop.circle.badge.checkmark",
                            title: "Today's Buddy",
                            subtitle: "You matched with Aiden — say hi!",
                            action: {}
                        )
                        .padding(.horizontal, Spacing.screenH)

                        // Challenges
                        ModuleCard {
                            Text("Challenges").font(.bodyLG).foregroundColor(.textOnLight)
                            ExpandableDataRow(title: "Coffee Chat Streak", subtitle: "2 of 3 completed", dotColor: .statusAway)
                            ExpandableDataRow(title: "Meet a New Buddy", subtitle: "Not started", dotColor: .statusNone)
                        }
                        .padding(.horizontal, Spacing.screenH)

                        // Campus pulse
                        ModuleCard {
                            Text("Campus Pulse").font(.bodyLG).foregroundColor(.textOnLight)
                            FilterPillGroup(options: ["All", "Events", "Study"], selected: $pulseFilter)
                            ExpandableDataRow(title: "Meet & Mingle — Friday", subtitle: "42 students interested", dotColor: .statusAvailable, showChevron: false)
                        }
                        .padding(.horizontal, Spacing.screenH)

                        Spacer(minLength: 100)
                    }
                    .padding(.top, 20)
                }
            }

            VStack {
                Spacer()
                BottomTabBar(selected: .constant(.home))
                    .padding(.bottom, 12)
            }
        }
    }
}

/// Helper for rounded-bottom header block seen across wireframes.
struct RoundedCorner: Shape {
    var radius: CGFloat = 25.0
    var corners: UIRectCorner = .allCorners

    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(roundedRect: rect, byRoundingCorners: corners,
                                 cornerRadii: CGSize(width: radius, height: radius))
        return Path(path.cgPath)
    }
}

#Preview {
    HomeView()
}
