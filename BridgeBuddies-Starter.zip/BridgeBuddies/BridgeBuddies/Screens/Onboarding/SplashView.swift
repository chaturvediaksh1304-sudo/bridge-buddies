import SwiftUI

struct SplashView: View {
    var body: some View {
        ZStack {
            LinearGradient.neutralBackground.ignoresSafeArea()

            VStack {
                Spacer()
                Text("Bridge Buddies")
                    .font(.displayLG)
                    .foregroundColor(.textOnDark)

                NavigationLink(destination: LoginView()) {
                    Text("Get Started")
                        .font(.bodyLG)
                        .foregroundColor(.textOnLight)
                        .padding(.horizontal, 40)
                        .padding(.vertical, 16)
                        .background(Color.surfaceCardPure)
                        .clipShape(Capsule())
                }
                .padding(.top, 24)

                Spacer()
                Spacer()

                Text("Making the first hello effortless.")
                    .font(.bodyMD)
                    .foregroundColor(.textOnDarkMuted)
                    .padding(.bottom, 40)
            }
        }
    }
}

struct LoginView: View {
    @State private var email = ""
    @State private var password = ""
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        ZStack {
            LinearGradient.neutralBackground.ignoresSafeArea()

            VStack(spacing: Spacing.stack) {
                HStack {
                    Button(action: { dismiss() }) {
                        Image(systemName: "arrow.left")
                            .frame(width: 44, height: 44)
                            .background(Color.surfaceCardPure)
                            .clipShape(Circle())
                    }
                    Spacer()
                }
                .padding(.horizontal, Spacing.screenH)

                Text("Login")
                    .font(.displayMD)
                    .foregroundColor(.textOnDark)
                    .padding(.bottom, Spacing.section)

                InputPill(label: "Email", text: $email)
                InputPill(label: "Password", text: $password, isSecure: true)
                    .padding(.horizontal, Spacing.screenH)

                HStack {
                    Text("Forgot Password?")
                        .font(.bodySM)
                        .foregroundColor(.textOnDarkMuted)
                    Spacer()
                }
                .padding(.horizontal, Spacing.screenH)

                PrimaryButton(title: "Log in", style: .dark) {}
                    .padding(.horizontal, Spacing.screenH)
                    .padding(.top, Spacing.stack)

                Spacer()
            }
            .padding(.top, 20)
        }
    }
}

#Preview {
    NavigationStack { SplashView() }
}
